const CACHE='worldai-v2-2';
const ASSETS=[
  './',
  './worldai_full_restored.html',
  'https://api.mapbox.com/mapbox-gl-js/v3.5.1/mapbox-gl.css',
  'https://api.mapbox.com/mapbox-gl-js/v3.5.1/mapbox-gl.js',
  'https://cdn.jsdelivr.net/npm/qrcodejs@1.0.0/qrcode.min.js'
];
self.addEventListener('install',e=>{e.waitUntil(caches.open(CACHE).then(c=>c.addAll(ASSETS)))});
self.addEventListener('fetch',e=>{e.respondWith(caches.match(e.request).then(r=>r||fetch(e.request).then(res=>{const copy=res.clone();caches.open(CACHE).then(c=>c.put(e.request,copy));return res})).catch(()=>caches.match('./')))});